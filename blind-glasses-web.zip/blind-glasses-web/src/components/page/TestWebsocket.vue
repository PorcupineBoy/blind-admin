<style>
    /* reset */
    html, body, h1, h2, h3, h4, h5, h6, div, dl, dt, dd, ul, ol, li, p, blockquote, pre, hr, figure, table, caption, th, td, form, fieldset, legend, input, button, textarea, menu{
        margin: 0;
        padding: 0;
    }
    header, footer, section, article, aside, nav, hgroup, address, figure, figcaption, menu, details{
        display: block;
    }
    table{
        border-collapse: collapse;
        border-spacing: 0;
    }
    caption, th{
        text-align: left;
        font-weight: normal;
    }
    html, body, fieldset, img, iframe, abbr{
        border: 0;
    }
    i, cite, em, var, address, dfn{
        font-style: normal;
    }
    [hidefocus], summary{
        outline: 0;
    }
    li{
        list-style: none;
    }
    h1, h2, h3, h4, h5, h6, small{
        font-size: 100%;
    }
    sup, sub{
        font-size: 83%;
    }
    pre, code, kbd, samp{
        font-family: inherit;
    }
    q:before, q:after{
        content: none;
    }
    textarea{
        overflow: auto;
        resize: none;
    }
    label, summary{
        cursor: default;
    }
    a, button{
        cursor: pointer;
    }
    h1, h2, h3, h4, h5, h6, em, strong, b{
        font-weight: bold;
    }
    del, ins, u, s, a, a:hover{
        text-decoration: none;
    }
    body, textarea, input, button, select, keygen, legend{
        font: 12px/1.14 arial,\5b8b\4f53;
        color: #333;
        outline: 0;
    }
    body{
        background: #fff;
    }
    a, a:hover{
        color: #333;
    }
    .u-btn{
        padding: 5px 10px;
        color: #fff;
        background-color: #238efa;
        border: 1px solid #0070d9;
        border-radius: 1px;
    }
    .u-btn:hover{
        color: #fff;
    }
    .u-btn{
        padding: 5px 10px;
        color: #fff;
        background-color: #238efa;
        border: 1px solid #0070d9;
        border-radius: 1px;
    }
    .u-btn:hover{
        color: #fff;
    }
    .m-list{
        zoom: 1;
        margin-top: 54px;
        margin-left: -10px;
    }
    .m-list .item{
        float: left;
        margin-left: 10px;
        margin-bottom: 30px;
        width: 243px;
        height: 190px;
        box-sizing: border-box;
        background-color: #fff;
        position: relative;
    }
    .m-list .item:hover{
        cursor: pointer;
    }
    .m-list .item:hover .play{
        display: block;
    }
    .m-list .snapshot{
        position: relative;
        width: 100%;
        height: 136px;
        overflow: hidden;
    }
    .m-list .snapshot .pic{
        width: 100%;
        background-color: #000;
    }
    .m-list .snapshot .play{
        display: none;
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.5);
    }
    .m-list .snapshot .play img{
        margin: 36px 0 0 94px;
    }
    .m-list .title{
        width: 100%;
        box-sizing: border-box;
        font-size: 14px;
        color: #1b2126;
        margin-top: 10px;
        padding: 0 10px;
        line-height: 14px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .m-list .online{
        width: 100%;
        box-sizing: border-box;
        font-size: 12px;
        color: #909ead;
        margin-top: 6px;
        padding: 0 10px;
        line-height: 12px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .m-list .status{
        position: absolute;
        top: 5px;
        left: 5px;
        width: 64px;
        height: 20px;
        text-align: center;
        background-color: #238efa;
        color: #fff;
        line-height: 20px;
    }
    .m-list:before, .m-list:after{
        display: table;
        content: "";
        line-height: 0;
    }
    .m-list:after{
        clear: both;
    }
    .u-btn{
        padding: 5px 10px;
        color: #fff;
        background-color: #238efa;
        border: 1px solid #0070d9;
        border-radius: 1px;
    }
    .u-btn:hover{
        color: #fff;
    }
    .m-room{
        margin-top: 10px;
        width: 100%;
        height: 750px;
        background-color: #f5f5f5;
        box-sizing: border-box;
        border-radius: 5px;
        zoom: 1;
    }
    .m-room .g-left{
        float: left;
        width: 850px;
        height: 100%;
        box-sizing: border-box;
        border: 1px solid #dcd4d4
    }
    .m-room .g-right{
        float: left;
        position: relative;
        width: 500px;
        height: 100%;
    }
    .m-room .g-right .bar {
        text-align: center;
        padding: 10px;
    }
    .m-room .g-right .routePlan {
        position: absolute;
        z-index: 1;
        height: 500px;
    }

    .m-room .g-right .planBus, .m-room .g-right .planWalk {
        font-size: 30px;
        color: #fbfbfbad;
        margin: 0 30px;
    }
    .m-room .g-right #closePlanBar {
        font-size: 25px;
        position: absolute;
        right: 20px;
        top: 14px;
    }
    .m-room .g-right #map {
        height: 100%;
    }
    .m-room .g-right #pickerBox{
        width: 100%;
        height: 80px;
        text-align: center;
    }
    .m-room .g-right #startPlace, .m-room .g-right #endPlace{
        width: 90%;
        height: 30px;
        font-size: 15px;
        margin: 5px 0
    }
    .m-room .g-right #toWalk,.m-room .g-right #toBus {
        background-color: #559ffb;
        box-shadow: 0px 1px 1px 0 rgba(0, 0, 0, 0.21);
        -webkit-box-shadow: 0px 1px 1px 0 rgba(0, 0, 0, 0.21);
        -moz-box-shadow: 0px 1px 1px 0 rgba(0, 0, 0, 0.21);
    }
    .amap-call {
        display: none;
    }
    .m-room .g-right #barMenu {
        position: absolute;
        z-index: 1;
        background-color: #559ffb;
        color: #fff;
        padding: 3px;
        font-size: 25px;
        top: 2px;
        left: 2px;
    }
    .m-room .g-right #panel{
        float: left;
        position: absolute;
        top: 200px;
        width: 358px;
        height: auto;
        max-height: 400px;
        overflow-y: scroll;
    }
    .m-room .g-right .active,.m-room .g-right .active {
        color: #fff;
    }
    .m-room .info{
        padding: 14px;
        height: 85px;
        width: 100%;
        box-sizing: border-box;
        overflow: hidden;
        border-bottom: 1px solid #cccccc;
    }
    .m-room .info .avatar{
        float: left;
        width: 56px;
        height: 56px;
        margin-right: 10px;
    }
    .m-room .info .image{
        border-radius: 50%;
        width: 100%;
        height: 100%;
        vertical-align: top;
        background-color: #fff;
    }
    .m-room .info .detail{
        overflow: hidden;
    }
    .m-room .info .title{
        margin-top: 4px;
        font-size: 20px;
        line-height: 20px;
        color: #3a4a59;
    }
    .m-room .info .desc{
        font-size: 12px;
        line-height: 12px;
        margin-top: 12px;
        color: #3a4a59;
    }
    .m-room .media{
        width: 100%;
        height: 660px;
        overflow: hidden;
    }
    .m-room .media img{
        width: 100%;
    }
    .m-room .announcement_title{
        width: 100%;
        height: 36px;
        line-height: 36px;
        font-size: 14px;
        color: #3a4a59;
        text-align: center;
    }
    .m-room .announcement{
        padding: 10px 15px;
        width: 100%;
        box-sizing: border-box;
        background-color: #f5fbff;
        height: 76px;
        border-bottom: 1px solid #ced4d9;
        color: #6b8299;
        line-height: 18px;
        overflow-y: scroll;
    }
    .m-room .tab{
        width: 100%;
        text-align: center;
        height: 38px;
        line-height: 38px;
        cursor: pointer;
        zoom: 1;
    }
    .m-room .tab li{
        float: left;
        width: 50%;
        height: 100%;
        box-sizing: border-box;
        background-color: #e5f4ff;
    }
    .m-room .tab li.crt{
        background-color: #fff;
        border-bottom: 2px solid #238efa;
    }
    .m-room .tab:before, .m-room .tab:after{
        display: table;
        content: "";
        line-height: 0;
    }
    .m-room .tab:after{
        clear: both;
    }
    .m-room .hide{
        display: none;
    }
    .m-room .chat{
        width: 100%;
        box-sizing: border-box;
        padding: 8px 10px;
        height: 306px;
        background-color: #fff;
        overflow-y: scroll;
    }
    .m-room .chat .item{
        box-sizing: border-box;
        margin-bottom: 4px;
    }
    .m-room .chat .nick{
        position: relative;
        display: inline-block;
        color: #88939b;
        font-size: 12px;
        line-height: 18px;
    }
    .m-room .chat .nick .role-manager{
        background-position: -33px -54px;
    }
    .m-room .chat .nick .role-owner{
        background-position: 0px -54px;
    }
    .m-room .chat .nick.roles{
        position: relative;
        padding-left: 34px;
    }
    .m-room .chat .emoji{
        width: 18px;
        height: 18px;
        vertical-align: top;
        float: none;
    }
    .m-room .chat .text{
        font-size: 12px;
        color: #333;
        line-height: 18px;
        word-wrap: break-word;
        word-break: break-all;
    }
    .m-room .chat .text.sys{
        color: red;
    }
    .m-room .chat.owner .nick{
        cursor: pointer;
    }
    .m-room .chat.owner .nick.owner, .m-room .chat.owner .nick.me{
        cursor: default;
    }
    .m-room .chat.manager .nick{
        cursor: pointer;
    }
    .m-room .chat.manager .nick.owner, .m-room .chat.manager .nick.manager, .m-room .chat.manager .nick.me{
        cursor: default;
    }
    .m-room .member{
        width: 100%;
        box-sizing: border-box;
        height: 306px;
        padding: 5px 0;
        background-color: #fff;
        overflow-y: scroll;
    }
    .m-room .member .item{
        width: 100%;
        position: relative;
        box-sizing: border-box;
        height: 35px;
        padding: 5px 10px 5px 45px;
        overflow: hidden;
    }
    .m-room .member .item .avatar{
        float: left;
        width: 25px;
        height: 25px;
        border-radius: 50%;
        overflow: hidden;
        margin-right: 5px;
    }
    .m-room .member .item .avatar img{
        width: 100%;
        height: 100%;
    }
    .m-room .member .item .nick{
        font-size: 14px;
        line-height: 25px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .m-room .member .item .role-manager{
        background-position: -33px -54px;
    }
    .m-room .member .item .role-owner{
        background-position: 0px -54px;
    }
    .m-room .member .item:hover{
        background-color: #eff8ff;
    }
    .m-room .member .more{
        width: 100%;
        text-align: center;
        line-height: 30px;
        height: 30px;
        font-size: 14px;
    }
    .m-room .member .more a{
        color: #238efa;
        text-decoration: underline;
    }
    .m-room .edit{
        width: 100%;
        height: 50px;
        padding: 7px 10px;
        box-sizing: border-box;
    }
    .m-room .edit .editText{
        width: 237px;
        height: 36px;
        padding: 4px 5px;
        margin: 0 auto;
        box-sizing: border-box;
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 2px;
    }
    .m-room .sendBtn{
        width: 100%;
        position: relative;
        padding-right: 10px;
        box-sizing: border-box;
        zoom: 1;
    }
    .m-room .sendBtn .btn{
        float: right;
        margin-left: 12px;
    }
    .m-room .sendBtn:before, .m-room .sendBtn:after{
        display: table;
        content: "";
        line-height: 0;
    }
    .m-room .sendBtn:after{
        clear: both;
    }
    .m-room .loginBtn{
        position: absolute;
        right: 10px;
        bottom: 20px;
    }
    .m-room .loginWarn{
        display: inline-block;
        margin: 10px;
        color: #999;
        font-weight: normal;
    }
    .m-room:before, .m-room:after{
        display: table;
        content: "";
        line-height: 0;
    }
    .m-room:after{
        clear: both;
    }
    .m-menu{
        position: absolute;
        border: 1px solid #ced0d1;
        background-color: #fff;
    }
    .m-menu ul li{
        width: 168px;
        height: 25px;
        line-height: 25px;
        text-align: center;
        cursor: pointer;
    }
    .m-menu ul li:hover{
        background-color: #e5f4ff;
    }
    .m-menu .admin{
        display: none;
    }
    .m-menu.owner .admin{
        display: block;
    }
    .m-status{
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: #fff;
        z-index: 200;
        text-align: center;
        line-height: 538px;
        font-size: 15px;
    }
    .u-btn{
        padding: 5px 10px;
        color: #fff;
        background-color: #238efa;
        border: 1px solid #0070d9;
        border-radius: 1px;
    }
    .u-btn:hover{
        color: #fff;
    }
    .m-manager{
        margin-top: 90px;
        width: 1002px;
        height: 538px;
        background-color: #e5f4ff;
        box-sizing: border-box;
        border-radius: 5px;
        overflow: hidden;
        zoom: 1;
    }
    .m-manager .tt{
        height: 38px;
        line-height: 38px;
        width: 100%;
        box-sizing: border-box;
        padding-left: 24px;
        color: #3a4a59;
        font-size: 15px;
        border-bottom: 1px solid #000;
    }
    .m-manager .item{
        width: 100%;
        display: block;
        height: 32px;
        line-height: 32px;
        font-size: 14px;
        color: #7b8794;
        padding-left: 44px;
        box-sizing: border-box;
    }
    .m-manager .item .icon{
        margin-right: 10px;
    }
    .m-manager .item.crt, .m-manager .item:hover{
        color: #fff;
        background-color: #93c4f5;
    }
    .m-manager .g-left{
        float: left;
        width: 230px;
        height: 100%;
        box-sizing: border-box;
        padding-top: 5px;
        border-right: 1px solid #434e58;
    }
    .m-manager .g-right{
        float: left;
        position: relative;
        width: 770px;
        height: 100%;
    }

    .m-manager:before, .m-manager:after{
        display: table;
        content: "";
        line-height: 0;
    }
    .m-manager:after{
        clear: both;
    }
    .u-ticon{
        display: inline-block;
        font-family: 'icomoon' !important;
        speak: none;
        font-style: normal;
        font-weight: normal;
        font-variant: normal;
        text-transform: none;
        line-height: 1;
        /* Better Font Rendering =========== */
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }
    .ticon-1:before{
        content: "\e900";
    }
    .ticon-2:before{
        content: "\e901";
    }
    .m-emoji-wrapper{
        display: none;
        position: absolute;
        border: 1px solid #ccc;
        width: 400px;
        height: 300px;
        background-color: #fff;
        position: absolute;
        top: -300px;
        left: -95px;
        z-index: 10;
    }
    .m-emoji-picCol{
        position: relative;
        background: #fff;
        overflow-y: scroll;
    }
    .m-emoji-picCol-ul{
        position: relative;
        list-style-type: none;
    }
    .m-emoji-picCol-ul:after{
        display: block;
        clear: both;
        visibility: hidden;
        height: 0;
        overflow: hidden;
        content: ".";
    }
    .m-emoji-picCol-ul{
        zoom: 1;
    }
    .m-emoji-picCol-ul span{
        float: left;
        display: inline-block;
        margin: 0;
        background: #fff;
        border-right: #eee 1px solid;
        border-bottom: #eee 1px solid;
        cursor: pointer;
        padding: 10px;
    }
    .m-emoji-picCol-ul span.f-sel{
        background-color: #ccc;
    }
    .m-emoji-picCol-ul span img{
        display: block;
        width: 100%;
        height: 100%;
    }
    .m-emoji-chnCol{
        position: relative;
        background: #f0f0f0;
    }
    .m-emoji-chnCol-ul{
        position: relative;
        list-style-type: none;
    }
    .m-emoji-chnCol-ul span{
        float: left;
        display: inline-block;
        height: 100%;
        width: 30px;
        background: #f0f0f0;
        cursor: pointer;
    }
    .m-emoji-chnCol-ul span.f-sel{
        background: #fff;
    }
    .m-emoji-chnCol-ul span img{
        display: block;
        height: 80%;
        width: auto;
        margin: 10%;
    }

    body{
        color: #3a4a59;
        font-family:"Hiragino Sans GB","Microsoft YaHei","微软雅黑",tahoma,arial;
    }

    body a:hover{
        color:#238efa;
    }
    /* 滚动条样式 */
    ::-webkit-scrollbar {
        width: 8px;
        background-color: transparent;
    }
    ::-webkit-scrollbar-thumb {
        background-color: #a0a9af;
        border-radius: 4px;
    }

    .g-doc{
        width: 100%;
        margin: 0 auto;
    }
    .m-head{
        width: 100%;
        height: 54px;
        background-color: #fff;
        border-top: 2px solid #238efa;
    }
    .m-head .g-doc{
        zoom: 1;
    }
    .m-head .g-doc:before, .m-head .g-doc:after{
        display: table;
        content: "";
        line-height: 0;
    }
    .m-head .g-doc:after{
        clear: both;
    }
    .m-head .item{
        display: inline-block;
        font-size: 14px;
        line-height: 54px;
        height: 54px;
        color: #1b2126;
    }
    .m-head .logo{
        padding-left: 30px;
    }
    .m-head .nav{
        margin-left: 20px;
    }
    .m-head .action{
        float: right;
        position: relative;
        margin-right: 40px;
        font-size: 12px;
        color:#909ead;
        cursor: pointer;
    }
    .m-head .action:hover{
        color: #238efa;
    }
    .m-head .action:hover .icon{
        background-position: -17px 0;
    }
    .m-head .info{
        float: right;
        position: relative;
        display: inline-block;
        padding-left: 35px;
        font-size: 12px;
        color:#909ead;
    }
    .m-head .info img{
        position: absolute;
        top:13px;
        left:0px;
        width: 25px;
        height: 25px;
        border-radius: 50%;
        background-color: yellow;
    }
    .m-head #nickName {
        cursor: pointer;
        color: #000;
    }


</style>
<template>
    <div id="container">
        <el-form ref="form" :rules="rules" :model="form" label-width="50px">
            <el-form-item label="帐号" prop="username">
                <el-input v-model="form.username" placeholder="1-10个字符"></el-input>
            </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
            <el-button type="primary" @click="initWebSocket">连接</el-button>
            <el-button type="primary" @click="responseFamily">响应亲属</el-button>
        </span>
    </div>
</template>

<script>
    import AMap from 'AMap'
    import AMapUI from 'AMapUI'

    export default {
        data() {
            return {
                serviceName: sessionStorage.getItem('ms_username'),
                blindName: '',
                stompClient: null,
                path: null,
                form: {
                    name: '',
                    username: '',
                    gender: '',
                    staffId: '',
                    password: ''
                },
                plugin: ['ToolBar', {
                    pName: 'MapType',
                    defaultType: 0,
                    events: {
                        init(o) {
                            console.log(o);
                        }
                    }
                }],
                data1: [ ],
            };
        },
        mounted() {
        },
        created() {


        },
        methods: {
            acceptBlind (index, row) {
                let _this = this
                this.stompClient.send("/app/service/accept", {}, JSON.stringify({
                    from: _this.serviceName,
                    to: row.blindName,
                    type: 'CUSTOM_ACCEPT'
                }));
                this.dialogTableVisible = false
                _this.deleteBlind(index, row)
            },
            deleteBlind(index, row) {
                this.data1.splice(index, 1)
            },
            initWebSocket() {
                let _this = this
                let socket = new SockJS('http://139.219.10.147:8888/travelhelper/im/webServer');
                ////let socket = new SockJS('/travelhelper/im/webServer');
                this.stompClient = Stomp.over(socket);
                this.stompClient.connect({
                    'username': _this.form.username,
                    'token': _this.form.username
                }, function success(frame) {
                    _this.stompClient.subscribe('/user/queue/blindLocation', function (msg) {
                        console.log(msg)
                    });
                    _this.stompClient.subscribe('/topic/blindRequest', function(r) {
                        console.log(r.body)
                    })
                    _this.stompClient.subscribe('/user/queue/family/request', function(msg) {
                        console.log(msg)
                    })
                    _this.stompClient.subscribe('/user/queue/family/accept', function(msg) {
                        console.log(msg)
                    })
                    _this.stompClient.subscribe('/user/queue/volunteer/request', function(msg) {
                        console.log(msg)
                    })
                    _this.stompClient.subscribe('/user/queue/volunteer/accept', function(msg) {
                        console.log(msg)
                    })
                }, function error(error) {
                    console.log(error)
                });
            },
            responseFamily() {
                let _this = this
                this.stompClient.send("/app/family/answer", {}, JSON.stringify({
                    from: _this.form.username,
                    to: 'blind1',
                    nickname: _this.form.username,
                    type: 'FAMILY_ANSWER'
                }));
            }
        }
    };
</script>

<style scoped>

</style>
